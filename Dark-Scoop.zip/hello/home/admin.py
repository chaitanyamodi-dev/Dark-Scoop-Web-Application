from django.contrib import admin
from .models import Contact1, Product, Order, OrderItem


@admin.register(Contact1)
class Contact1Admin(admin.ModelAdmin):
    list_display = ("name", "email", "message")


@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ("name", "category", "price", "stock", "is_available")
    prepopulated_fields = {"slug": ("name",)}


@admin.register(Order)
class OrderAdmin(admin.ModelAdmin):
    list_display = ("id", "name", "status", "payment_method", "payment_status", "email_verified", "date")
    list_filter = ("status", "payment_method", "payment_status", "email_verified")
    search_fields = ("name", "email", "transaction_id")


@admin.register(OrderItem)
class OrderItemAdmin(admin.ModelAdmin):
    list_display = ("order", "product_name", "quantity", "unit_price")
