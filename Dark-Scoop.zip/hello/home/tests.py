from decimal import Decimal
from datetime import timedelta

from django.contrib.auth.models import User
from django.test import TestCase, override_settings
from django.urls import reverse
from django.utils import timezone

from .models import OTPVerification, Order, Product


class NavigationTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("scoop", password="safe-password-123")

    def test_public_navigation_pages_load(self):
        for name in ("home", "about", "flavours", "services", "contact", "cart", "login", "register"):
            with self.subTest(page=name):
                self.assertEqual(self.client.get(reverse(name)).status_code, 200)

    def test_logout_requires_post_and_clears_session(self):
        self.client.force_login(self.user)
        self.assertEqual(self.client.get(reverse("logout")).status_code, 405)
        response = self.client.post(reverse("logout"))
        self.assertRedirects(response, reverse("signed-out"))
        self.assertNotIn("_auth_user_id", self.client.session)


class CheckoutTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user("buyer", email="buyer@example.com", password="safe-password-123")
        self.product = Product.objects.create(
            name="Test Scoop", slug="test-scoop", category="Test", price=Decimal("120.00"),
            description="Test product", stock=4,
        )
        self.client.force_login(self.user)
        session = self.client.session
        session["cart"] = {str(self.product.pk): 2}
        session.save()

    @override_settings(EMAIL_BACKEND="django.core.mail.backends.locmem.EmailBackend")
    def test_otp_rejects_invalid_guess_and_checkout_requires_matching_email(self):
        response = self.client.post(reverse("send-otp"), {"email": "buyer@example.com"})
        self.assertEqual(response.status_code, 200)
        response = self.client.post(reverse("verify-otp"), {"otp": "000000"})
        self.assertEqual(response.status_code, 400)
        self.assertEqual(OTPVerification.objects.get().attempts, 1)

        response = self.client.post(reverse("checkout"), {
            "name": "Buyer", "email": "other@example.com", "phone": "9876543210",
            "address": "Test address", "notes": "", "payment_method": "COD",
        })
        self.assertRedirects(response, reverse("checkout"))
        self.assertEqual(Order.objects.count(), 0)

    def test_verified_checkout_creates_gateway_ready_order(self):
        otp = OTPVerification(email="buyer@example.com", expires_at=timezone.now() + timedelta(minutes=5), is_verified=True)
        otp.set_otp("123456")
        otp.save()
        session = self.client.session
        session["verified_email"] = "buyer@example.com"
        session["verified_otp_id"] = otp.pk
        session.save()

        response = self.client.post(reverse("checkout"), {
            "name": "Buyer", "email": "buyer@example.com", "phone": "9876543210",
            "address": "Test address", "notes": "", "payment_method": "CARD",
        })
        order = Order.objects.get()
        self.assertRedirects(response, reverse("order-success", kwargs={"pk": order.pk}))
        self.assertEqual(order.payment_status, Order.PaymentStatus.SUCCESS)
        self.assertTrue(order.email_verified)
        self.assertTrue(order.transaction_id.startswith("pay_simulated_"))
