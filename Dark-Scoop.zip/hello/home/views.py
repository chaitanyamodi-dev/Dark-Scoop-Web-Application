from django.contrib import messages
from decimal import Decimal
from django.db import transaction
from django.contrib.auth import authenticate, login, logout
from django.shortcuts import get_object_or_404, render, redirect
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required, user_passes_test
import uuid
from .models import Contact1, Order, OrderItem, Product
from django.db.models import Q
from .forms import CheckoutForm, ContactForm, ProductForm

from django.utils import timezone
from datetime import timedelta
from django.core.mail import send_mail
from django.http import Http404, JsonResponse
from django.views.decorators.http import require_POST
from django.views.decorators.csrf import csrf_exempt
from .models import OTPVerification, Order
from django.core.validators import validate_email
from django.utils.http import url_has_allowed_host_and_scheme
from django.core.exceptions import ValidationError
import logging
import io
import base64
from django.conf import settings
import random

try:
    import qrcode
except Exception:
    qrcode = None

try:
    from openai import OpenAI

    _openai_client = (
        OpenAI(api_key=getattr(settings, "OPENAI_API_KEY", None))
        if getattr(settings, "OPENAI_API_KEY", None)
        else None
    )
except Exception:
    OpenAI = None
    _openai_client = None

from django.utils import timezone
from datetime import timedelta

logger = logging.getLogger(__name__)


@login_required(login_url="login")
@require_POST
def send_otp(request):
    email = (request.POST.get("email") or "").strip().lower()
    try:
        validate_email(email)
    except ValidationError:
        return JsonResponse(
            {"success": False, "error": "Enter a valid email address."}, status=400
        )

    last_sent = request.session.get("otp_last_sent_at")
    now = timezone.now()
    if last_sent and now.timestamp() - last_sent < 60:
        return JsonResponse(
            {"success": False, "error": "Please wait before requesting another code."},
            status=429,
        )

    code = OTPVerification.generate_code()
    otp = OTPVerification(email=email, expires_at=now + timedelta(minutes=10))
    otp.set_otp(code)
    otp.save()

    try:
        send_mail(
            subject="Your DarkScoop checkout verification code",
            message=f"Your verification code is {code}. It expires in 10 minutes.",
            from_email=None,
            recipient_list=[email],
        )
    except Exception:
        logger.exception("Unable to send checkout OTP")
        otp.delete()
        return JsonResponse(
            {
                "success": False,
                "error": "We could not send the code. Please try again.",
            },
            status=503,
        )

    request.session["checkout_otp_id"] = otp.pk
    request.session["otp_last_sent_at"] = now.timestamp()
    request.session.pop("verified_email", None)
    return JsonResponse(
        {
            "success": True,
            "message": "Verification code sent.",
            "expires_in": 600,
            "resend_in": 60,
        }
    )


@require_POST
def ria_chat(request):
    """RIA — real AI chatbot for DarkScoop. Deterministic actions (add-to-cart,
    UPI QR generation) stay hard-coded because they mutate the DB/session.
    Everything else is answered by a real LLM call, with a clear message
    only if the LLM is genuinely unavailable or fails."""
    import re
    import json
    import random
    import logging
    import uuid

    logger = logging.getLogger(__name__)

    try:
        payload = json.loads(request.body.decode("utf-8"))
        text = (payload.get("message") or "").strip()
    except Exception:
        text = (request.POST.get("message") or "").strip()

    user_msg = text.lower()

    # ---- Pending add-to-cart flow (deterministic) ----
    pending = request.session.get("ria_pending_add")
    if pending and user_msg:
        size = None
        extras = []
        if "small" in user_msg:
            size = "Small"
        elif "medium" in user_msg:
            size = "Medium"
        elif "large" in user_msg:
            size = "Large"

        if "nut" in user_msg or "nuts" in user_msg:
            extras.append("Nuts")
        if "sprinkle" in user_msg or "sprinkles" in user_msg:
            extras.append("Sprinkles")
        if "chocolate" in user_msg or "sauce" in user_msg:
            extras.append("Chocolate Sauce")

        if "cancel" in user_msg or user_msg.strip() == "no":
            request.session.pop("ria_pending_add", None)
            return JsonResponse({"reply": "RIA: Okay, cancelled adding to cart."})

        if not size:
            return JsonResponse(
                {
                    "reply": "RIA: Which size would you like? Options: Small, Medium, Large.",
                    "needs_options": True,
                    "sizes": ["Small", "Medium", "Large"],
                }
            )

        product_pk = pending.get("product_pk")
        qty = pending.get("quantity", 1)
        try:
            product = Product.objects.get(pk=product_pk, is_available=True)
        except Exception:
            request.session.pop("ria_pending_add", None)
            return JsonResponse(
                {"reply": "RIA: Sorry, that product is no longer available."},
                status=404,
            )

        cart = request.session.get("cart", {})
        cart[str(product.pk)] = min(
            product.stock, int(cart.get(str(product.pk), 0)) + qty
        )
        request.session["cart"] = cart

        cart_options = request.session.get("cart_options", {})
        cart_options[str(product.pk)] = {"size": size, "extras": extras}
        request.session["cart_options"] = cart_options

        request.session.pop("ria_pending_add", None)
        return JsonResponse(
            {
                "reply": f"RIA: Added {qty} x {product.name} ({size}{', ' + ', '.join(extras) if extras else ''}) to your cart.",
                "added": True,
                "product_pk": product.pk,
                "quantity": cart.get(str(product.pk), 0),
            }
        )

    def format_bot_reply(text):
        suffixes = [
            "Would you like me to add that to your cart?",
            "Do you want a recommendation too?",
            "I can prepare that for checkout when you're ready.",
            "Want me to find similar flavours?",
            "Happy to help — what next?",
            "Shall I add that to your cart?",
        ]
        emoji = random.choice(["😊", "🍦", "🙂", "😄"])
        if random.random() < 0.4:
            return f"RIA: {text} {random.choice(suffixes)} {emoji}"
        return f"RIA: {text} {emoji}"

    def reply(text):
        return {"reply": format_bot_reply(text)}

    if not user_msg:
        return JsonResponse(
            reply(
                "Hi — I'm RIA. Ask me about menu, orders, payments or ask for suggestions."
            )
        )

    # ---- UPI QR deterministic action ----
    m = re.search(
        r"(?:upi\s*qr|generate upi qr|upi)\s*(?:for)?\s*(\d+(?:\.\d{1,2})?)", user_msg
    )
    if m:
        amount = m.group(1)
        merchant_vpa = getattr(settings, "UPI_MERCHANT_VPA", "merchant@upi")
        merchant_name = getattr(settings, "UPI_MERCHANT_NAME", "DarkScoop")
        upi_uri = f"upi://pay?pa={merchant_vpa}&pn={merchant_name}&tr=chat_{uuid.uuid4().hex[:8]}&am={amount}&cu=INR&tn=Chat%20Payment"
        qr_data_uri = None
        if qrcode:
            try:
                img = qrcode.make(upi_uri)
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                qr_b64 = base64.b64encode(buf.getvalue()).decode()
                qr_data_uri = f"data:image/png;base64,{qr_b64}"
            except Exception:
                qr_data_uri = None
        if qr_data_uri:
            return JsonResponse(
                {
                    "reply": f"RIA: Generated UPI QR for ₹{amount}",
                    "qr": qr_data_uri,
                    "upi": upi_uri,
                }
            )
        else:
            return JsonResponse(
                {
                    "reply": f"RIA: Could not generate QR, but use this UPI link: {upi_uri}",
                    "upi": upi_uri,
                }
            )

    # ---- Add-to-cart intent (tightened regex, deterministic) ----
    m2 = re.search(
        r"\b(?:add|order|buy|get|want|i'?ll have)\b.{0,10}?(\d+)\s+([a-zA-Z &]+)",
        user_msg,
    )
    if m2:
        qty = int(m2.group(1))
        name = m2.group(2).strip()
        matched = None
        try:
            for f in ICECREAM_FLAVOURS:
                if f["name"].lower().startswith(name) or name in f["name"].lower():
                    matched = f
                    break
        except Exception:
            matched = None
        if matched:
            product = (
                Product.objects.filter(name__iexact=matched["name"]).first()
                or Product.objects.filter(name__icontains=matched["name"]).first()
            )
            if product:
                request.session["ria_pending_add"] = {
                    "product_pk": product.pk,
                    "quantity": qty,
                }
                return JsonResponse(
                    {
                        "reply": f"RIA: I can add {qty} x {product.name} — what size would you like? (Small, Medium, Large). You can also request extras like Nuts, Sprinkles or Chocolate Sauce.",
                        "needs_options": True,
                        "product_pk": product.pk,
                        "sizes": ["Small", "Medium", "Large"],
                        "extras": ["Nuts", "Sprinkles", "Chocolate Sauce"],
                    }
                )
            else:
                return JsonResponse(
                    reply(
                        f"Added {qty} x {matched['name']} to a draft cart. Open Cart to review and checkout."
                    )
                )

    # ---- Everything else: real LLM reply ----
    llm_enabled = bool(_openai_client) and getattr(settings, "RIA_USE_LLM", False)
    reason = None
    if not llm_enabled:
        reason = (
            "OPENAI_API_KEY is not set in settings.py"
            if not _openai_client
            else "RIA_USE_LLM is not set to True in settings.py"
        )
        logger.warning("RIA is not using the LLM: %s", reason)

    if llm_enabled:
        menu_lines = "\n".join(
            f"- {f['name']}: {f['description']} (₹{f['price']})"
            for f in ICECREAM_FLAVOURS
        )
        try:
            resp = _openai_client.chat.completions.create(
                model=getattr(settings, "OPENAI_MODEL", "gpt-4o-mini"),
                messages=[
                    {
                        "role": "system",
                        "content": (
                            "You are RIA, the friendly AI assistant for DarkScoop, an ice cream shop. "
                            "Answer naturally and conversationally, like a helpful human staff member — "
                            "not a scripted bot. Keep replies short (2-4 sentences max) and warm.\n\n"
                            + f"Current menu:\n{menu_lines}\n\n"
                            + "You can also help with: order status/tracking (tell them to check 'My Orders'), "
                            "payment methods (COD, UPI via QR, Card), and contact info (hello@darkscoop.com). "
                            "If someone wants to add something to their cart or generate a payment QR, tell them "
                            "to just say things like 'add 1 Mango' or 'generate UPI QR for 199' and you'll handle it."
                        ),
                    },
                    {"role": "user", "content": text},
                ],
                max_tokens=250,
                temperature=0.7,
            )
            content = resp.choices[0].message.content.strip()
            return JsonResponse({"reply": format_bot_reply(content)})
        except Exception:
            logger.exception("OpenAI request failed")
            return JsonResponse(
                reply(
                    "I'm having trouble reaching my AI brain right now 😅 Please try again in a moment."
                )
            )

    return JsonResponse(
        reply(
            f"My AI connection isn't set up yet ({reason}). I can still help with menu items, orders, payments, or say 'Generate UPI QR for 199'."
        )
    )


@require_POST
def ria_generate_upi_qr(request):
    """Generate a UPI QR image for a given amount and optionally vpa.

    Accepts JSON: {amount: '199.00', vpa: 'merchant@upi'}
    Returns JSON: {qr: data-uri, upi: upi_uri}
    """
    import json

    try:
        payload = json.loads(request.body.decode("utf-8"))
    except Exception:
        payload = request.POST.dict()

    amount = payload.get("amount")
    vpa = payload.get("vpa") or getattr(settings, "UPI_MERCHANT_VPA", "merchant@upi")
    name = getattr(settings, "UPI_MERCHANT_NAME", "DarkScoop")
    if not amount:
        return JsonResponse({"error": "amount required"}, status=400)

    upi_uri = f"upi://pay?pa={vpa}&pn={name}&tr=chat_{uuid.uuid4().hex[:8]}&am={amount}&cu=INR&tn=Chat%20Payment"
    qr_data_uri = None
    if qrcode:
        try:
            img = qrcode.make(upi_uri)
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            qr_b64 = base64.b64encode(buf.getvalue()).decode()
            qr_data_uri = f"data:image/png;base64,{qr_b64}"
        except Exception:
            qr_data_uri = None

    result = {"upi": upi_uri}
    if qr_data_uri:
        result["qr"] = qr_data_uri

    return JsonResponse(result)


@require_POST
def ria_add(request):
    """API to add an item to cart directly from chat buttons.

    Accepts JSON or form: {product_pk, quantity (opt), size (opt), extras (opt array)}
    """
    import json

    try:
        payload = json.loads(request.body.decode("utf-8"))
    except Exception:
        payload = request.POST.dict()

    pk = payload.get("product_pk")
    if not pk:
        return JsonResponse({"error": "product_pk required"}, status=400)

    try:
        pk = int(pk)
    except Exception:
        return JsonResponse({"error": "invalid product_pk"}, status=400)

    try:
        product = Product.objects.get(pk=pk, is_available=True)
    except Product.DoesNotExist:
        return JsonResponse({"error": "product not found"}, status=404)

    try:
        quantity = int(payload.get("quantity", 1))
    except Exception:
        quantity = 1

    size = payload.get("size")
    extras = payload.get("extras") or []
    if isinstance(extras, str):
        try:
            extras = json.loads(extras)
        except Exception:
            extras = [extras]

    cart = request.session.get("cart", {})
    cart[str(product.pk)] = min(
        product.stock, int(cart.get(str(product.pk), 0)) + quantity
    )
    request.session["cart"] = cart

    cart_options = request.session.get("cart_options", {})
    cart_options[str(product.pk)] = {"size": size, "extras": extras}
    request.session["cart_options"] = cart_options

    return JsonResponse(
        {
            "reply": f"RIA: Added {quantity} x {product.name} ({size or 'Standard'}{', ' + ', '.join(extras) if extras else ''}) to your cart.",
            "added": True,
            "product_pk": product.pk,
            "quantity": cart.get(str(product.pk), 0),
        }
    )


@login_required(login_url="login")
@require_POST
def verify_otp(request):
    code = (request.POST.get("otp") or "").strip()
    otp_id = request.session.get("checkout_otp_id")

    if not otp_id:
        return JsonResponse(
            {"success": False, "error": "No OTP session found"}, status=400
        )

    try:
        otp = OTPVerification.objects.get(pk=otp_id)
    except OTPVerification.DoesNotExist:
        return JsonResponse({"success": False, "error": "OTP not found"}, status=404)

    if otp.is_expired():
        return JsonResponse({"success": False, "error": "OTP expired"}, status=400)

    if otp.attempts >= 5:
        return JsonResponse(
            {"success": False, "error": "Too many attempts. Request a new code."},
            status=429,
        )

    if len(code) != 6 or not code.isdigit() or not otp.check_otp(code):
        otp.attempts += 1
        otp.save(update_fields=["attempts"])
        return JsonResponse({"success": False, "error": "Incorrect OTP"}, status=400)

    otp.is_verified = True
    otp.save()
    request.session["verified_email"] = otp.email
    request.session["verified_otp_id"] = otp.pk
    return JsonResponse({"success": True, "message": "Email verified"})


# Create your views here.
def home(request):

    latest_flavours = [
        {
            "name": "Blue Moon",
            "description": "A dreamy, creamy and delicious blue ice cream.",
            "price": 120,
            "image": "img/moon.jpg",
            "tag": "Paris Style✨",
        },
        {
            "name": "Banana Pudding",
            "description": "Creamy banana ice cream with delicious pudding flavour.",
            "price": 130,
            "image": "img/banana.jpg",
            "tag": "Turkey's Style ✨",
        },
        {
            "name": "Moose Tracks",
            "description": "Rich chocolate ice cream with peanut butter goodness.",
            "price": 140,
            "image": "img/moose.jpg",
            "tag": "American Style ✨",
        },
    ]
    flavours = [
        {
            "name": "Strawberry",
            "description": "Fresh, fruity and creamy strawberry ice cream.",
            "price": 100,
            "image": "img/strawberry.avif",
        },
        {
            "name": "Chocolate",
            "description": "Rich and creamy chocolate ice cream.",
            "price": 110,
            "image": "img/choco.jpg",
        },
        {
            "name": "Vanilla",
            "description": "Classic smooth and creamy vanilla ice cream.",
            "price": 100,
            "image": "img/vanilla.avif",
        },
        {
            "name": "Butterscotch",
            "description": "Sweet and buttery butterscotch ice cream.",
            "price": 120,
            "image": "img/butterscotch.jpg",
        },
        {
            "name": "Mango",
            "description": "Sweet and refreshing tropical mango ice cream.",
            "price": 110,
            "image": "img/mango.AVIF",
        },
        {
            "name": "Cookies & Cream",
            "description": "Creamy vanilla ice cream loaded with cookie crunch.",
            "price": 130,
            "image": "img/cookies.jpg",
        },
    ]

    context = {
        "latest_flavours": latest_flavours,
        "flavours": flavours,
    }
    return render(request, "index.html", context)


def about(request):
    context = {"variable_value": "This is variable value from views.py"}
    return render(request, "about.html", context)
    # return HttpResponse("This is About Page")


def services(request):
    return render(request, "services.html")


def contact(request):

    if request.method == "POST":
        form = ContactForm(request.POST)

        if form.is_valid():
            form.save()

            messages.success(request, "Your message has been sent successfully! 🍦")

            return redirect("contact")

    else:
        form = ContactForm()

    return render(request, "contact.html", {"form": form})


def subscribe(request):
    if request.method == "POST":
        messages.success(
            request, "You are subscribed! Look out for sweet news from us."
        )
    return redirect("home")


def index(request):
    return render(request, "index.html")


def login_view(request):

    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(request, username=username, password=password)

        if user is not None:
            login(request, user)

            messages.success(request, "Welcome back! 🍦")

            next_url = request.POST.get("next")

            if next_url and url_has_allowed_host_and_scheme(
                next_url,
                allowed_hosts={request.get_host()},
                require_https=request.is_secure(),
            ):
                return redirect(next_url)

            return redirect("home")

        else:
            messages.error(request, "Invalid username or password.")

    return render(request, "login.html")


def register_view(request):

    if request.method == "POST":
        username = request.POST.get("username")
        email = request.POST.get("email")
        password = request.POST.get("password")
        confirm_password = request.POST.get("confirm_password")

        # Check passwords

        if password != confirm_password:
            messages.error(request, "Passwords do not match.")

            return redirect("register")

        # Check username

        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists.")

            return redirect("register")

        # Create user

        user = User.objects.create_user(
            username=username, email=email, password=password
        )

        messages.success(request, "Account created successfully! 🍦")

        return redirect("login")

    return render(request, "register.html")


def cart_view(request):
    context = _cart_context(request)
    # show product images in cart according to session preference (default true)
    context["show_product_images_in_cart"] = bool(
        request.session.get("cart_show_thumbs", True)
    )
    return render(request, "cart.html", context)


@require_POST
def toggle_cart_thumbs(request):
    """Toggle/show product thumbnails in cart (session-backed). Accepts JSON {show: true/false} or form.`"""
    import json

    try:
        payload = json.loads(request.body.decode("utf-8"))
    except Exception:
        payload = request.POST.dict()

    show = payload.get("show")
    if show is None:
        # toggle
        current = bool(request.session.get("cart_show_thumbs", True))
        request.session["cart_show_thumbs"] = not current
    else:
        # accept strings
        if isinstance(show, str):
            show = show.lower() in ("1", "true", "yes", "on")
        request.session["cart_show_thumbs"] = bool(show)

    return JsonResponse({"show": bool(request.session.get("cart_show_thumbs", True))})


@require_POST
def logout_view(request):

    logout(request)

    messages.success(request, "You have been logged out successfully. 👋")

    return redirect("signed-out")


def signed_out_view(request):
    return render(request, "signed_out.html")


ICECREAM_FLAVOURS = [
    {
        "slug": "chocolate-delight",
        "name": "Chocolate Delight",
        "emoji": "🍫",
        "description": "Rich, smooth chocolate ice cream with a delicious chocolate finish.",
        "price": 120,
        "image": "img/chocolate.jpg",
        "tag": "Bestseller",
        "tag_slug": "bestseller",
    },
    {
        "slug": "strawberry-bliss",
        "name": "Strawberry Bliss",
        "emoji": "🍓",
        "description": "Fresh and creamy strawberry ice cream with a fruity finish.",
        "price": 100,
        "image": "img/strawberry.avif",
        "tag": "Popular",
        "tag_slug": "popular",
    },
    {
        "slug": "classic-vanilla",
        "name": "Classic Vanilla",
        "emoji": "🍨",
        "description": "Smooth, creamy vanilla with a timeless and elegant taste.",
        "price": 90,
        "image": "img/vanilla.avif",
        "tag": "Classic",
        "tag_slug": "classic",
    },
    {
        "slug": "butterscotch-crunch",
        "name": "Butterscotch Crunch",
        "emoji": "🍯",
        "description": "Creamy butterscotch blended with crunchy caramel pieces.",
        "price": 110,
        "image": "img/butterscotch.jpg",
        "tag": "Favourite",
        "tag_slug": "favourite",
    },
    {
        "slug": "mango-magic",
        "name": "Mango Magic",
        "emoji": "🥭",
        "description": "Sweet and refreshing mango ice cream bursting with flavour.",
        "price": 100,
        "image": "img/mango.avif",
        "tag": "Seasonal",
        "tag_slug": "seasonal",
    },
    {
        "slug": "cookies-and-cream",
        "name": "Cookies & Cream",
        "emoji": "🍪",
        "description": "Creamy vanilla ice cream loaded with crunchy cookie pieces.",
        "price": 130,
        "image": "img/cookies.jpg",
        "tag": "New",
        "tag_slug": "new",
    },
]
LATEST_FLAVOURS = [
    {
        "slug": "banana-pudding",
        "name": "Banana Pudding",
        "emoji": "🍌",
        "description": "Creamy banana ice cream with vanilla wafer pieces and a smooth pudding swirl.",
        "price": 160,
        "image": "img/banana.jpg",
        "tag": "American Special",
        "tag_slug": "american-special",
    },
    {
        "slug": "blue-moon",
        "name": "Blue Moon",
        "emoji": "💙",
        "description": "A bright blue Midwestern-style ice cream with a sweet, mysterious citrus-like flavour.",
        "price": 170,
        "image": "img/moon.jpg",
        "tag": "USA Original",
        "tag_slug": "usa-original",
    },
    {
        "slug": "moose-tracks",
        "name": "Moose Tracks",
        "emoji": "🥜",
        "description": "Creamy vanilla ice cream packed with peanut butter cups and rich chocolate fudge.",
        "price": 180,
        "image": "img/moose.jpg",
        "tag": "American Special",
        "tag_slug": "american-special",
    },
]


def chunk(items, size=3):
    """Split a flat list into groups of `size` for the carousel slides."""
    return [items[i : i + size] for i in range(0, len(items), size)]


def icecream_view(request):
    """List available products and support simple search via GET `q`.

    The search matches product name or description (case-insensitive).
    """
    q = (request.GET.get("q") or "").strip()
    base_qs = Product.objects.filter(is_available=True)

    if q:
        base_qs = base_qs.filter(Q(name__icontains=q) | Q(description__icontains=q))

    flavours = base_qs.order_by("name")

    return render(request, "flavours.html", {"flavours": flavours, "search_query": q})


@login_required(login_url="login")
def order(request):

    if request.method == "POST":
        Order.objects.create(
            name=request.POST.get("name"),
            email=request.POST.get("email"),
            phone=request.POST.get("phone"),
            flavour=request.POST.get("flavour"),
            quantity=request.POST.get("quantity"),
            address=request.POST.get("address"),
            notes=request.POST.get("notes"),
        )

        messages.success(request, "Your order has been placed successfully! 🍦")

        return redirect("order")

    context = {
        "flavours": ICECREAM_FLAVOURS,
        "latest_flavours": LATEST_FLAVOURS,
    }

    return render(request, "order.html", context)


def _cart_context(request):
    cart = {
        int(pk): quantity for pk, quantity in request.session.get("cart", {}).items()
    }
    cart_options = request.session.get("cart_options", {})
    products = Product.objects.filter(pk__in=cart, is_available=True)
    rows = [
        {
            "product": product,
            "quantity": cart[product.pk],
            "subtotal": product.price * cart[product.pk],
            "options": cart_options.get(str(product.pk)),
        }
        for product in products
    ]
    return {
        "rows": rows,
        "total": sum((row["subtotal"] for row in rows), Decimal("0.00")),
    }


def product_detail(request, slug):
    return render(
        request,
        "product_detail.html",
        {"product": get_object_or_404(Product, slug=slug, is_available=True)},
    )


def cart_add(request, pk):
    product = get_object_or_404(Product, pk=pk, is_available=True)
    if request.method == "POST":
        cart = request.session.get("cart", {})
        try:
            quantity = max(1, int(request.POST.get("quantity", 1)))
        except (TypeError, ValueError):
            quantity = 1
        cart[str(pk)] = min(product.stock, int(cart.get(str(pk), 0)) + quantity)
        request.session["cart"] = cart
        messages.success(request, f"{product.name} added to your cart.")
    return redirect(request.POST.get("next", "cart"))


def cart_detail(request):
    return render(request, "cart.html", _cart_context(request))


def cart_update(request, pk):
    if request.method == "POST":
        product = get_object_or_404(Product, pk=pk, is_available=True)
        cart = request.session.get("cart", {})
        try:
            quantity = int(request.POST.get("quantity", 1))
        except (TypeError, ValueError):
            quantity = 1
        if quantity > 0:
            cart[str(pk)] = min(quantity, product.stock)
            if quantity > product.stock:
                messages.warning(
                    request,
                    f"Quantity adjusted to the {product.stock} available {product.name} scoops.",
                )
        else:
            cart.pop(str(pk), None)
        request.session["cart"] = cart
    return redirect("cart")


def cart_remove(request, pk):
    if request.method == "POST":
        cart = request.session.get("cart", {})
        cart.pop(str(pk), None)
        request.session["cart"] = cart
    return redirect("cart")


@login_required(login_url="login")
def checkout(request):
    context = _cart_context(request)
    if not context["rows"]:
        messages.error(request, "Your cart is empty.")
        return redirect("flavours")

    form = CheckoutForm(
        request.POST or None,
        initial={
            "name": request.user.get_full_name() or request.user.username,
            "email": request.user.email,
        },
    )

    if request.method == "POST" and form.is_valid():
        verified_otp_id = request.session.get("verified_otp_id")
        verified_email = request.session.get("verified_email")
        otp_is_valid = OTPVerification.objects.filter(
            pk=verified_otp_id,
            email=form.cleaned_data["email"].lower(),
            is_verified=True,
            expires_at__gt=timezone.now(),
        ).exists()
        if not otp_is_valid or verified_email != form.cleaned_data["email"].lower():
            messages.error(
                request, "Verify this checkout email before placing the order."
            )
            return redirect("checkout")

        order_data = form.cleaned_data.copy()
        payment_method = order_data.pop("payment_method")

        with transaction.atomic():
            order = Order.objects.create(
                user=request.user,
                status=Order.Status.PENDING,
                flavour="Cart order",
                quantity=sum(row["quantity"] for row in context["rows"]),
                payment_method=payment_method,
                # For UPI keep payment pending until the user completes payment via QR
                payment_status=(
                    Order.PaymentStatus.PENDING
                    if payment_method
                    in (Order.PaymentMethod.COD, Order.PaymentMethod.UPI)
                    else Order.PaymentStatus.SUCCESS
                ),
                transaction_id=f"pay_simulated_{uuid.uuid4().hex[:10]}",
                email_verified=True,
                **order_data,
            )
            for row in context["rows"]:
                product = Product.objects.select_for_update().get(pk=row["product"].pk)
                if product.stock < row["quantity"]:
                    messages.error(
                        request, f"Only {product.stock} of {product.name} remain."
                    )
                    return redirect("cart")
                product.stock -= row["quantity"]
                product.is_available = product.stock > 0
                product.save()
                OrderItem.objects.create(
                    order=order,
                    product=product,
                    product_name=product.name,
                    unit_price=product.price,
                    quantity=row["quantity"],
                )

        request.session["cart"] = {}
        request.session.pop("verified_email", None)
        request.session.pop("verified_otp_id", None)
        request.session.pop("checkout_otp_id", None)

        return redirect("order-success", pk=order.pk)

    context["form"] = form
    return render(request, "checkout.html", context)


@login_required(login_url="login")
def order_history(request):
    return render(
        request,
        "order_history.html",
        {"orders": request.user.orders.prefetch_related("items").order_by("-date")},
    )


@login_required(login_url="login")
def order_detail(request, pk):
    order = get_object_or_404(
        request.user.orders.prefetch_related("items__product"), pk=pk
    )
    timeline = [
        (Order.Status.PENDING, "Order placed", "We’ve received your order."),
        (Order.Status.CONFIRMED, "Confirmed", "Your order has been confirmed."),
        (Order.Status.PREPARING, "Preparing", "Our kitchen is preparing your scoops."),
        (
            Order.Status.OUT_FOR_DELIVERY,
            "Out for delivery",
            "Your order is on its way.",
        ),
        (Order.Status.DELIVERED, "Delivered", "Enjoy every scoop!"),
    ]
    current_index = next(
        (index for index, step in enumerate(timeline) if step[0] == order.status),
        -1,
    )
    return render(
        request,
        "order_detail.html",
        {"order": order, "timeline": timeline, "current_index": current_index},
    )


@login_required(login_url="login")
@require_POST
def cancel_order(request, pk):
    with transaction.atomic():
        order = get_object_or_404(
            request.user.orders.select_for_update().prefetch_related("items__product"),
            pk=pk,
        )
        if order.status != Order.Status.PENDING:
            messages.error(request, "Only pending orders can be cancelled.")
            return redirect("order-detail", pk=order.pk)
        for item in order.items.all():
            product = Product.objects.select_for_update().get(pk=item.product_id)
            product.stock += item.quantity
            product.is_available = True
            product.save(update_fields=["stock", "is_available"])
        order.status = Order.Status.CANCELLED
        order.save(update_fields=["status"])
    messages.success(request, "Your order was cancelled and stock was restored.")
    return redirect("order-detail", pk=order.pk)


@login_required(login_url="login")
@require_POST
def reorder(request, pk):
    order = get_object_or_404(
        request.user.orders.prefetch_related("items__product"), pk=pk
    )
    cart = request.session.get("cart", {})
    added = 0
    for item in order.items.all():
        product = item.product
        if not product.is_available or product.stock == 0:
            continue
        existing = int(cart.get(str(product.pk), 0))
        cart[str(product.pk)] = min(product.stock, existing + item.quantity)
        added += 1
    request.session["cart"] = cart
    if added:
        messages.success(request, "Available items were added to your cart.")
    else:
        messages.warning(request, "None of these items are currently available.")
    return redirect("cart")


@login_required(login_url="login")
def order_success(request, pk):
    order = get_object_or_404(request.user.orders.prefetch_related("items"), pk=pk)
    qr_data_uri = None
    upi_uri = None
    # If the order is UPI and still pending, generate a UPI payment URI and QR
    if (
        order.payment_method == Order.PaymentMethod.UPI
        and order.payment_status != Order.PaymentStatus.SUCCESS
    ):
        merchant_vpa = getattr(settings, "UPI_MERCHANT_VPA", "merchant@upi")
        merchant_name = getattr(settings, "UPI_MERCHANT_NAME", "DarkScoop")
        amount = order.total if order.total is not None else 0
        # Build a simple UPI URI
        upi_uri = (
            f"upi://pay?pa={merchant_vpa}&pn={merchant_name}&tr={order.transaction_id}"
            f"&am={amount}&cu=INR&tn=Order%20%23{order.pk}"
        )
        if qrcode:
            try:
                img = qrcode.make(upi_uri)
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                qr_b64 = base64.b64encode(buf.getvalue()).decode()
                qr_data_uri = f"data:image/png;base64,{qr_b64}"
            except Exception:
                qr_data_uri = None

    return render(
        request,
        "order_success.html",
        {"order": order, "qr_data_uri": qr_data_uri, "upi_uri": upi_uri},
    )


@login_required(login_url="login")
@require_POST
def confirm_upi_payment(request, pk):
    """Simple endpoint to mark a UPI order as paid (demo mode)."""
    order = get_object_or_404(request.user.orders, pk=pk)
    if order.payment_method != Order.PaymentMethod.UPI:
        return JsonResponse({"success": False, "error": "Not a UPI order."}, status=400)
    order.payment_status = Order.PaymentStatus.SUCCESS
    order.save(update_fields=["payment_status"])
    return JsonResponse({"success": True})


staff_required = user_passes_test(lambda user: user.is_staff, login_url="login")


@staff_required
def product_list(request):
    return render(
        request,
        "product_management.html",
        {"products": Product.objects.order_by("name")},
    )


@staff_required
def product_create(request):
    form = ProductForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("product-list")
    return render(request, "product_form.html", {"form": form, "title": "Add product"})


@staff_required
def product_update(request, pk):
    form = ProductForm(request.POST or None, instance=get_object_or_404(Product, pk=pk))
    if request.method == "POST" and form.is_valid():
        form.save()
        return redirect("product-list")
    return render(request, "product_form.html", {"form": form, "title": "Edit product"})


@staff_required
def product_delete(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == "POST":
        product.delete()
        return redirect("product-list")
    return render(request, "product_delete.html", {"product": product})
