from django import forms
from .models import Contact1, Order, Product


class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact1
        fields = [
            "name",
            "email",
            "message",
            "phone",
            "subject",
        ]
        widgets = {
            "name": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "Enter your name"}
            ),
            "email": forms.EmailInput(
                attrs={"class": "form-control", "placeholder": "Enter your email"}
            ),
            "phone": forms.TextInput(
                attrs={
                    "class": "form-control",
                    "placeholder": "Enter your phone number",
                }
            ),
            "subject": forms.TextInput(
                attrs={"class": "form-control", "placeholder": "Enter subject"}
            ),
            "message": forms.Textarea(
                attrs={
                    "class": "form-control",
                    "placeholder": "Write your message...",
                    "rows": 5,
                }
            ),
        }


class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ("name", "slug", "category", "description", "image", "price", "stock", "is_available")


class CheckoutForm(forms.Form):
    name = forms.CharField(max_length=100, widget=forms.TextInput(attrs={"autocomplete": "name"}))
    email = forms.EmailField()
    phone = forms.CharField(max_length=15, widget=forms.TextInput(attrs={"autocomplete": "tel"}))
    address = forms.CharField(widget=forms.Textarea(attrs={"autocomplete": "street-address"}))
    notes = forms.CharField(required=False, widget=forms.Textarea)
    payment_method = forms.ChoiceField(choices=Order.PaymentMethod.choices, widget=forms.RadioSelect)

    def clean_phone(self):
        phone = "".join(character for character in self.cleaned_data["phone"] if character.isdigit())
        if not 10 <= len(phone) <= 15:
            raise forms.ValidationError("Enter a valid phone number.")
        return phone
