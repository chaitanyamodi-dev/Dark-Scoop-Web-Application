from django.urls import path
from home import views


urlpatterns = [
    # HOME
    path("", views.home, name="home"),
    # OTHER PAGES
    path("about/", views.about, name="about"),
    path("flavours/", views.icecream_view, name="flavours"),
    path("flavours/<slug:slug>/", views.product_detail, name="product-detail"),
    path("services/", views.services, name="services"),
    path("contact/", views.contact, name="contact"),
    path("order/", views.cart_detail, name="order"),
    path("cart/", views.cart_view, name="cart"),
    path("cart/add/<int:pk>/", views.cart_add, name="cart-add"),
    path("cart/update/<int:pk>/", views.cart_update, name="cart-update"),
    path("cart/remove/<int:pk>/", views.cart_remove, name="cart-remove"),
    path("checkout/", views.checkout, name="checkout"),
    path("checkout/send-otp/", views.send_otp, name="send-otp"),
    path("checkout/verify-otp/", views.verify_otp, name="verify-otp"),
    path("checkout/success/<int:pk>/", views.order_success, name="order-success"),
    path(
        "orders/<int:pk>/confirm-upi/",
        views.confirm_upi_payment,
        name="confirm-upi-payment",
    ),
    path("chat/ria/", views.ria_chat, name="ria-chat"),
    path("chat/ria/upi/", views.ria_generate_upi_qr, name="ria-generate-upi"),
    path("chat/ria/add/", views.ria_add, name="ria-add"),
    path("cart/toggle-thumbs/", views.toggle_cart_thumbs, name="toggle-cart-thumbs"),
    path("orders/", views.order_history, name="order-history"),
    path("orders/<int:pk>/", views.order_detail, name="order-detail"),
    path("orders/<int:pk>/cancel/", views.cancel_order, name="cancel-order"),
    path("orders/<int:pk>/reorder/", views.reorder, name="reorder"),
    path("manage/products/", views.product_list, name="product-list"),
    path("manage/products/add/", views.product_create, name="product-create"),
    path("manage/products/<int:pk>/edit/", views.product_update, name="product-update"),
    path(
        "manage/products/<int:pk>/delete/", views.product_delete, name="product-delete"
    ),
    # INDEX PAGE
    path("index/", views.index, name="index"),
    # AUTHENTICATION
    path("login/", views.login_view, name="login"),
    path("logout/", views.logout_view, name="logout"),
    path("signed-out/", views.signed_out_view, name="signed-out"),
    path("register/", views.register_view, name="register"),
]
