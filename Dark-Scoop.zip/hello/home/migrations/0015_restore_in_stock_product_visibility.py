from django.db import migrations


def restore_in_stock_products(apps, schema_editor):
    Product = apps.get_model("home", "Product")
    Product.objects.filter(stock__gt=0, is_available=False).update(is_available=True)


class Migration(migrations.Migration):
    dependencies = [("home", "0014_secure_checkout_payment_metadata")]
    operations = [migrations.RunPython(restore_in_stock_products, migrations.RunPython.noop)]
