from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("home", "0015_restore_in_stock_product_visibility")]
    operations = [
        migrations.AlterField(
            model_name="order",
            name="status",
            field=models.CharField(
                choices=[
                    ("pending", "Pending"), ("confirmed", "Confirmed"),
                    ("preparing", "Preparing"),
                    ("out_for_delivery", "Out for delivery"),
                    ("delivered", "Delivered"),
                    ("cancelled", "Cancelled"),
                ],
                default="pending",
                max_length=20,
            ),
        )
    ]
