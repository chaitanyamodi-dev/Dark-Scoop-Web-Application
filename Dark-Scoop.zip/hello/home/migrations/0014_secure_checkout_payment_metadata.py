from django.db import migrations, models


class Migration(migrations.Migration):
    dependencies = [("home", "0013_alter_order_payment_method")]

    operations = [
        migrations.AddField(model_name="otpverification", name="attempts", field=models.PositiveSmallIntegerField(default=0)),
        migrations.AddField(model_name="order", name="email_verified", field=models.BooleanField(default=False)),
        migrations.AddField(model_name="order", name="transaction_id", field=models.CharField(blank=True, db_index=True, max_length=64)),
        migrations.AlterField(model_name="order", name="payment_status", field=models.CharField(choices=[("PENDING", "Pending"), ("SUCCESS", "Success"), ("FAILED", "Failed")], default="PENDING", max_length=10)),
    ]
