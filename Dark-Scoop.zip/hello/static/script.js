const menuButton = document.querySelector('.menu-button');
const navigation = document.querySelector('.nav');


document.addEventListener("DOMContentLoaded", function () {

    const messages = document.querySelectorAll(".custom-toast");

    messages.forEach(function (message) {

        setTimeout(function () {

            message.style.opacity = "0";
            message.style.transform = "translateX(50px)";

            message.style.transition =
                "opacity 0.3s ease, transform 0.3s ease";

            setTimeout(function () {
                message.remove();
            }, 300);

        }, 5000);

    });

});


document.querySelectorAll('.nav a').forEach((link) => {
  link.addEventListener('click', () => {
    navigation.classList.remove('open');
    menuButton.setAttribute('aria-expanded', 'false');
  });
});

document.querySelectorAll('.filter').forEach((button) => {
  button.addEventListener('click', () => {
    document.querySelector('.filter.active').classList.remove('active');
    button.classList.add('active');
    const selected = button.dataset.filter;
    document.querySelectorAll('.flavour-card').forEach((card) => {
      card.hidden = selected !== 'all' && card.dataset.category !== selected;
    });
  });
});

document.querySelector('.contact-form').addEventListener('submit', (event) => {
  event.preventDefault();
  event.currentTarget.reset();
  document.querySelector('.form-message').textContent = 'Thanks! We will get back to you soon.';
});
