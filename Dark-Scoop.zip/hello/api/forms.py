from django import forms

from .models import Item


class ItemForm(forms.ModelForm):
    class Meta:
        model = Item
        fields = ("category", "subcategory", "name", "amount")
        widgets = {
            "category": forms.TextInput(attrs={"placeholder": "e.g. Ice cream"}),
            "subcategory": forms.TextInput(attrs={"placeholder": "e.g. Seasonal"}),
            "name": forms.TextInput(attrs={"placeholder": "Item name"}),
            "amount": forms.NumberInput(attrs={"min": 0, "placeholder": "0"}),
        }
