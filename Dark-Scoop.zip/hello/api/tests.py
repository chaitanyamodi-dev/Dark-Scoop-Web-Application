from rest_framework import status
from rest_framework.test import APITestCase
from django.contrib.auth.models import User
from django.test import TestCase
from django.urls import reverse

from .models import Item


class ItemApiTests(APITestCase):
    def setUp(self):
        self.item = Item.objects.create(
            category="Ice Cream",
            subcategory="Classic",
            name="Vanilla Bean",
            amount=120,
        )

    def test_api_overview_is_available(self):
        response = self.client.get("/api/")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn("endpoints", response.data)

    def test_create_and_list_items(self):
        response = self.client.post(
            "/api/items/",
            {
                "category": "Ice Cream",
                "subcategory": "Fruit",
                "name": "Mango Magic",
                "amount": 140,
            },
            format="json",
        )

        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertIn("id", response.data)
        self.assertEqual(Item.objects.count(), 2)

        response = self.client.get("/api/items/?category=ice%20cream")

        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data), 2)

    def test_retrieve_update_and_delete_item(self):
        detail_url = f"/api/items/{self.item.pk}/"

        response = self.client.get(detail_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["name"], "Vanilla Bean")

        response = self.client.patch(detail_url, {"amount": 150}, format="json")
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data["amount"], 150)

        response = self.client.delete(detail_url)
        self.assertEqual(response.status_code, status.HTTP_204_NO_CONTENT)
        self.assertFalse(Item.objects.filter(pk=self.item.pk).exists())


class ItemManagementViewsTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(username="manager", password="test-pass-123")
        self.item = Item.objects.create(
            category="Ice Cream", subcategory="Classic", name="Vanilla Bean", amount=120
        )
        self.client.force_login(self.user)

    def test_inventory_requires_login(self):
        self.client.logout()

        response = self.client.get(reverse("api:item-list"))

        self.assertRedirects(response, "/login/?next=/api/manage/items/")

    def test_create_update_and_delete_from_management_pages(self):
        response = self.client.post(
            reverse("api:item-list"),
            {"category": "Ice Cream", "subcategory": "Fruit", "name": "Mango Magic", "amount": 140},
        )
        self.assertRedirects(response, reverse("api:item-list"))
        created = Item.objects.get(name="Mango Magic")

        response = self.client.post(
            reverse("api:item-update", args=[created.pk]),
            {"category": "Ice Cream", "subcategory": "Fruit", "name": "Mango Sorbet", "amount": 160},
        )
        self.assertRedirects(response, reverse("api:item-list"))
        created.refresh_from_db()
        self.assertEqual(created.name, "Mango Sorbet")

        response = self.client.post(reverse("api:item-delete", args=[created.pk]))
        self.assertRedirects(response, reverse("api:item-list"))
        self.assertFalse(Item.objects.filter(pk=created.pk).exists())
