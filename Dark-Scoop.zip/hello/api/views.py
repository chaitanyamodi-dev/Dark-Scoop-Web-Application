from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render
from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import generics

from .models import Item
from .serializers import ItemSerializer


@login_required(login_url="login")
def item_list(request):
    """Display the inventory and handle new item submissions."""
    from .forms import ItemForm

    form = ItemForm(request.POST or None)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Item added to the inventory.")
        return redirect("api:item-list")

    return render(
        request,
        "api/item_list.html",
        {
            "items": Item.objects.all().order_by("category", "subcategory", "name"),
            "form": form,
        },
    )


@login_required(login_url="login")
def item_update(request, pk):
    """Edit one inventory item."""
    from .forms import ItemForm

    item = get_object_or_404(Item, pk=pk)
    form = ItemForm(request.POST or None, instance=item)
    if request.method == "POST" and form.is_valid():
        form.save()
        messages.success(request, "Item updated.")
        return redirect("api:item-list")

    return render(request, "api/item_form.html", {"form": form, "item": item})


@login_required(login_url="login")
def item_delete(request, pk):
    """Require a confirmation page before removing an inventory item."""
    item = get_object_or_404(Item, pk=pk)
    if request.method == "POST":
        item.delete()
        messages.success(request, "Item deleted.")
        return redirect("api:item-list")

    return render(request, "api/item_confirm_delete.html", {"item": item})


@api_view(["GET"])
def api_overview(request):
    """Describe the API endpoints available to API consumers."""
    return Response(
        {
            "message": "Welcome to the DarkScoop API.",
            "endpoints": {
                "items": "/api/items/",
                "create_item": "/api/items/ (POST)",
                "item_detail": "/api/items/<id>/",
            },
        }
    )


@api_view(["GET", "POST"])
def items(request):
    """List items, optionally filtered by category/subcategory, or create one."""
    if request.method == "POST":
        serializer = ItemSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    queryset = Item.objects.all().order_by("id")
    category = request.query_params.get("category")
    subcategory = request.query_params.get("subcategory")

    if category:
        queryset = queryset.filter(category__iexact=category)
    if subcategory:
        queryset = queryset.filter(subcategory__iexact=subcategory)

    return Response(ItemSerializer(queryset, many=True).data)


@api_view(["GET", "PUT", "PATCH", "DELETE"])
def item_detail(request, pk):
    """Retrieve, edit, or remove a single item."""
    item = get_object_or_404(Item, pk=pk)

    if request.method == "GET":
        return Response(ItemSerializer(item).data)

    if request.method in ("PUT", "PATCH"):
        serializer = ItemSerializer(
            item, data=request.data, partial=request.method == "PATCH"
        )
        serializer.is_valid(raise_exception=True)
        serializer.save()
        return Response(serializer.data)

    item.delete()
    return Response(status=status.HTTP_204_NO_CONTENT)


class ItemCreateView(generics.CreateAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerializer
