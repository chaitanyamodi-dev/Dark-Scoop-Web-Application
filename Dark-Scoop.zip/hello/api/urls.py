from django.urls import path

from . import views

app_name = "api"

urlpatterns = [
    path("manage/items/", views.item_list, name="item-list"),
    path("manage/items/<int:pk>/edit/", views.item_update, name="item-update"),
    path("manage/items/<int:pk>/delete/", views.item_delete, name="item-delete"),
    path("", views.api_overview, name="overview"),
    path("items/", views.items, name="items"),
    path("items/<int:pk>/", views.item_detail, name="item-detail"),
    path("items/create/", views.ItemCreateView.as_view(), name="item-create"),
]
